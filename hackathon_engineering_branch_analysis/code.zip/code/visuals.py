import pandas as pd
import matplotlib
matplotlib.use('Agg')  
import matplotlib.pyplot as plt
import seaborn as sns
import os

class BranchVisualizer:
    def __init__(self, data_path='dataset1.xlsx', output_dir='static/plots'):
        self.df = pd.read_excel(data_path)
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _save_plot(self, fig, filename):
        path = os.path.join(self.output_dir, filename)
        fig.savefig(path, bbox_inches='tight')
        plt.close(fig)
        return f'static/plots/{filename}'  

    def avg_closing_rank(self):
        avg_rank = self.df.groupby('branch')['closing rank'].mean().sort_values()
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.barplot(x=avg_rank.values, y=avg_rank.index, ax=ax, palette="magma")
        ax.set_title('Average Closing Rank by Branch')
        ax.set_xlabel('Average Closing Rank')
        ax.set_ylabel('Branch')
        return self._save_plot(fig, 'avg_closing_rank.png')

    def trend(self):
        fig, ax = plt.subplots(figsize=(12, 8))
        for branch in self.df['branch'].unique():
            trend = self.df[self.df['branch'] == branch].groupby('year')['closing rank'].mean()
            ax.plot(trend.index, trend.values, marker='o', label=branch)
        ax.set_title('Average Closing Rank Trend per Year (All Branches)')
        ax.set_xlabel('Year')
        ax.set_ylabel('Avg Closing Rank')
        ax.legend(fontsize='small', loc='upper right', bbox_to_anchor=(1.3, 1.0))
        ax.grid(True)
        return self._save_plot(fig, 'trend.png')

    def boxplot(self):
        fig, ax = plt.subplots(figsize=(12, 6))
        sns.boxplot(data=self.df, x='branch', y='closing rank', ax=ax, palette="coolwarm")
        ax.set_title('Closing Rank Distribution by Branch')
        ax.set_xlabel('Branch')
        ax.set_ylabel('Closing Rank')
        plt.xticks(rotation=45)
        return self._save_plot(fig, 'boxplot.png')

    def institute_count(self):
        inst_count = self.df.groupby('branch')['institute'].nunique().sort_values(ascending=False)
        fig, ax = plt.subplots(figsize=(10, 6))
        sns.barplot(x=inst_count.values, y=inst_count.index, ax=ax, palette="magma")
        ax.set_title('Number of IITs Offering Each Branch')
        ax.set_xlabel('Number of IITs')
        ax.set_ylabel('Branch')
        return self._save_plot(fig, 'institute_count.png')

    def heatmap(self):
        pivot = self.df.pivot_table(index='branch', columns='year', values='closing rank', aggfunc='mean')
        fig, ax = plt.subplots(figsize=(12, 6))
        sns.heatmap(pivot, annot=True, fmt=".0f", cmap="magma", ax=ax)
        ax.set_title('Heatmap of Average Closing Ranks per Branch per Year')
        return self._save_plot(fig, 'heatmap.png')


    def pie_branch(self):
        counts = self.df['branch'].value_counts()
        fig, ax = plt.subplots(figsize=(8, 8))
        ax.pie(counts.values, labels=counts.index, autopct='%1.1f%%', startangle=140)
        ax.set_title('Distribution of Branch Entries')
        return self._save_plot(fig, 'pie_branch.png')
