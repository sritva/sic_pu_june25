from flask import Flask, render_template, request, jsonify
from visuals import BranchVisualizer

app = Flask(__name__)
visualizer = BranchVisualizer(data_path='dataset1.xlsx')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/plot', methods=['POST'])
def plot():
    data = request.get_json()
    plot_type = data.get('plot_type')

    plot_methods = {
        'avg_closing_rank': visualizer.avg_closing_rank,
        'trend': visualizer.trend,
        'boxplot': visualizer.boxplot,
        'institute_count': visualizer.institute_count,
        'heatmap': visualizer.heatmap,
        'pie_branch': visualizer.pie_branch,
    }

    if plot_type in plot_methods:
        plot_path = plot_methods[plot_type]()
        return jsonify({'plot_url': '/' + plot_path})
    else:
        return jsonify({'error': 'Invalid plot type'}), 400

if __name__ == '__main__':
    app.run(debug=True)
